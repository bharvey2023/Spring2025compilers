

import java.util.*;

public class SimpleTableBuilder extends LittleBaseListener {

    private final ArrayList<String> tinyCode = new ArrayList<>();
    private final ArrayList<String> IR = new ArrayList<>();
    private final Map<String, String> types = new HashMap<>(); // Store variable types
    //private final ArrayList<String> loads = new ArrayList<>();
    private int count = 1;
    private int tinyCnt = 0;
    private final int MAX_REGS = 10;


    public void prettyPrint() {

        for (String s : IR) {
            System.out.println(s);
        }
        //for(String s : loads) {System.out.println(s);}

        for (String s : tinyCode) {
            System.out.println(s);
        }
    }

    @Override
    public void enterString_decl(LittleParser.String_declContext ctx){
        String name = ctx.id().getText();
        types.put(name, "STRING");
        //loads.add("str " + name + " " + ctx.str().getText());
        tinyCode.add("str " + name + " " + ctx.str().getText());

    }

    @Override
    public void enterVar_decl(LittleParser.Var_declContext ctx) {
        String[] names = ctx.id_list().getText().split(",");
        String tp = ctx.var_type().getText(); // Get the type of the variable (INT, FLOAT, etc.)


        for(String name : names) {
            tinyCode.add("var " + name);
            //loads.add("var " + name);
            if (tp.equals("FLOAT")) {
                types.put(name, "FLOAT"); // Mark the variable as a Float type
            } else if (tp.equals("STRING")) {
                types.put(name, "STRING"); // Mark the variable as a String type
            } else {
                types.put(name, "INT"); // Mark the variable as an Integer type
            }
        }
    }

    @Override
    public void enterProgram(LittleParser.ProgramContext ctx) {
        IR.add(";IR code");
        tinyCode.add(";tiny code");
        //loads.add(";tiny code");
    }

    @Override
    public void enterFunc_decl(LittleParser.Func_declContext ctx){
        IR.add(";LABEL "+ ctx.id().getText());
        IR.add(";LINK");
    }

    @Override
    public void exitProgram(LittleParser.ProgramContext ctx){
        IR.add(";RET");
        tinyCode.add("sys halt");
    }

    @Override
    public void enterAssign_stmt(LittleParser.Assign_stmtContext ctx){
        String handle = ctx.assign_expr().expr().getText();
        String val = ctx.assign_expr().id().getText();

        // Clean the handle string by removing parentheses
        handle = handle.replace("(", "");
        handle = handle.replace(")", "");

        String type = types.get(val); // Get the type of the variable being assigned
        char grab = ' ';
        char tiny = ' ';
        if (type.equals("STRING")) {
            grab = 'S';
            tiny = 's';
        } else if (type.equals("FLOAT")) {
            grab = 'F';
            tiny = 'r';
        } else {
            grab = 'I';
            tiny = 'i';
        }
        if(handle.contains("*")){
            String[] parts = handle.split("\\*");
            String left = parts[0].trim();
            String right = parts[1].trim();

            IR.add(";MULT" + grab + " " + left + " " + right + " $T"+count);
            tinyCode.add("move " + left + " r" + tinyCnt);
            tinyCode.add("mul" + tiny + " " + right + " r" + tinyCnt);

        } else if(handle.contains("+")){
            String[] parts = handle.split("\\+");
            String left = parts[0].trim();
            String right = parts[1].trim();

            IR.add(";ADD" + grab + " " + left + " " + right + " $T"+count);
            tinyCode.add("move " + left + " r" + tinyCnt);
            tinyCode.add("add" + tiny + " " + right + " r" + tinyCnt);
        } else if(handle.contains("-")){
            String[] parts = handle.split("-");
            String left = parts[0].trim();
            String right = parts[1].trim();

            IR.add(";SUB" + grab + " " + left + " " + right + " $T"+count);
            tinyCode.add("move " + left + " r" + tinyCnt);
            tinyCode.add("sub" + tiny + " " + right + " r" + tinyCnt);
        } else if(handle.contains("/")){
            String[] parts = handle.split("/");
            String left = parts[0].trim();
            String right = parts[1].trim();

            IR.add(";DIV" + grab + " " + left + " " + right + " $T"+count);
            tinyCode.add("move " + left + " r" + tinyCnt);
            tinyCode.add("div" + tiny + " " + right + " r" + tinyCnt);
        } else {
            // Loading constants
            if (type.equals("STRING")) {
                IR.add(";STORES " + handle + " $T" + count); // For String type
            } else if (type.equals("FLOAT")) {
                IR.add(";STOREF " + handle + " $T" + count); // For Float type
            } else {
                IR.add(";STOREI " + handle + " $T" + count); // For Int type
            }
            tinyCode.add("move " + handle + " r" + tinyCnt);
            //loads.add("move " + handle + " r" + tinyCnt);

        }

        // Storing
        if (type.equals("STRING")) {
            IR.add(";STORE" + "S" + " $T" + count + " " + val); // For String type
        } else if (type.equals("FLOAT")) {
            IR.add(";STORE" + "F" + " $T" + count + " " + val); // For Float type
        } else {
            IR.add(";STORE" + "I" + " $T" + count + " " + val); // For Int type
        }
        tinyCode.add("move " + "r" + tinyCnt + " " + val);
        //loads.add("move " + "r" + tinyCnt + " " + val);
        count++;
        tinyCnt++;

    }

    @Override
    public void enterRead_stmt(LittleParser.Read_stmtContext ctx){
        String many = ctx.id_list().getText();
        String[] check = many.split(",");

        for(String s : check){
            // Retrieve the type of the variable to determine the correct read instruction
            String type = types.get(s);

            if (type != null) {
                if (type.equals("STRING")) {
                    IR.add(";READS " + s); // Read as String
                    tinyCode.add("sys reads " + s);
                } else if (type.equals("FLOAT")) {
                    IR.add(";READF " + s); // Read as Float
                    tinyCode.add("sys readr " + s);
                } else {
                    IR.add(";READI " + s); // Read as Integer
                    tinyCode.add("sys readi " + s);
                }
            }
        }
    }

    @Override
    public void enterWrite_stmt(LittleParser.Write_stmtContext ctx){
        String many = ctx.id_list().getText();
        String[] check = many.split(",");

        for(String s : check){
            // Retrieve the type of the variable to determine the correct write instruction
            String type = types.get(s);

            if (type != null) {
                if (type.equals("STRING")) {
                    IR.add(";WRITES " + s); // Write as String
                    tinyCode.add("sys writes " + s);
                } else if (type.equals("FLOAT")) {
                    IR.add(";WRITEF " + s); // Write as Float
                    tinyCode.add("sys writer " + s);
                } else {
                    IR.add(";WRITEI " + s); // Write as Integer
                    tinyCode.add("sys writei " + s);
                }
            }
        }
    }



}

